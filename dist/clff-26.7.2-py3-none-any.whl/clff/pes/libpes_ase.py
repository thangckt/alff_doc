"""Library for ASE-based PES operations."""

from copy import deepcopy

from clff.base import KEY as K
from clff.base import logger
from clff.gdata.libgen_ase import OpGendataAseOptimize
from thkit.config import Config
from thkit.io import read_yaml, write_yaml


#####ANCHOR Stage 1 - GPAW optimize initial structure
class OpPESAseOptimize(OpGendataAseOptimize):
    """This class does ASE optimization for a list of structures in `task_dirs`.

    This class can also be used for phonon ASE optimization
    """

    def __init__(self, work_dir, pdict, multi_mdict, mdict_prefix="ase"):
        super().__init__(work_dir, pdict, multi_mdict, mdict_prefix)
        return

    def prepare(self):
        ### Refer functions from `libgen_gpaw.py`
        """Prepare the operation.

        Includes:
        - Prepare ase_args for GPAW and gpaw_run_file. Note: Must define `pdict.dft.calc_args.gpaw{}` for this function.
        - Prepare the task_list
        - Prepare forward & backward files
        - Prepare commandlist_list for multi-remote submission
        """
        work_dir = self.work_dir
        pdict = self.pdict

        ### Prepare ase_args
        ase_args = {}
        ase_args.setdefault("structure", {})["from_extxyz"] = f"{K.FILE_FRAME_UNLABEL}"
        ase_args["calc_args"] = deepcopy(pdict["calculator"].get("calc_args", {}))
        ase_args["optimize"] = pdict.get("optimize_args", {}).get("ase", {})

        ase_args = self._correct_ase_pyfile_path(ase_args)
        Config.validate(config_dict=ase_args, schema_file=K.SCHEMA_ASE_RUN)
        write_yaml(ase_args, f"{work_dir}/{K.FILE_ARG_ASE}")

        ### ASE_runfile
        self.RUNFILE_ASE = "cli_ase_optimize.py"
        self._prepare_runfile_ase()
        return

    def postprocess(self):
        ### Do nothing
        return


#####ANCHOR Stage 4 - compute energy by DFT/MD
class OpPESAseOptimizeFixatom(OpPESAseOptimize):
    """Perform optimization with some atoms fixed."""

    def __init__(self, work_dir, pdict, multi_mdict, mdict_prefix="ase"):
        super().__init__(work_dir, pdict, multi_mdict, mdict_prefix)
        self.op_name = "ASE optimize fixed atoms"
        return

    def prepare(self):
        work_dir = self.work_dir
        pdict = self.pdict

        ### Prepare ase_args
        ase_args = {}
        ase_args.setdefault("structure", {})["from_extxyz"] = f"{K.FILE_FRAME_UNLABEL}"
        ase_args["calc_args"] = deepcopy(pdict["calculator"].get("calc_args", {}))
        ase_args["optimize"] = pdict["optimize_args"].get("ase", {})
        ### Read fixed atoms
        fixed_atoms = read_yaml(f"{work_dir}/fix_idxs.yml")
        ase_args.setdefault("constraint", {})["fix_atoms"] = {}
        ase_args["constraint"]["fix_atoms"]["fix_idxs"] = fixed_atoms
        if pdict.get("constraint", {}).get("fix_atoms", {}).get("fix_dim_z", False):
            ase_args["constraint"]["fix_atoms"]["fix_dim_z"] = True
            logger.info("Only fix atom positions in z-direction.")
        else:
            logger.info("Fix atom positions in all directions.")

        ase_args = self._correct_ase_pyfile_path(ase_args)
        Config.validate(config_dict=ase_args, schema_file=K.SCHEMA_ASE_RUN)
        write_yaml(ase_args, f"{work_dir}/{K.FILE_ARG_ASE}")

        ### ASE_runfile
        self.RUNFILE_ASE = "cli_ase_optimize.py"
        self._prepare_runfile_ase()
        return
