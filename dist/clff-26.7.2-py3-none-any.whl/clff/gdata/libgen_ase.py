"""Module for ASE-compatible calculator to be used in CLFF's workflows."""
### Similar to libgen_gpaw.py, but for ASE-compatible calculator

from copy import deepcopy

from clff.base import KEY as K
from clff.base import RemoteOperation
from clff.gdata.util_dataset import remove_key_in_extxyz
from thkit.config import Config
from thkit.io import write_yaml
from thkit.path import copy_file, filter_dirs, remove_files_in_paths


#####SECTION Classes for data generation
#####ANCHOR Stage 1 - ASE optimize initial structure
class OpGendataAseOptimize(RemoteOperation):
    """This class does ASE optimization for a list of structures in `task_dirs`."""

    def __init__(self, work_dir, pdict, multi_mdict, mdict_prefix="ase"):
        super().__init__(work_dir, pdict, multi_mdict, mdict_prefix)
        # self.calc_name = "gpaw"
        self.op_name = "ASE optimize"
        self.task_filter = {
            "has_files": [K.FILE_FRAME_UNLABEL],
            "no_files": [K.FILE_FRAME_LABEL],
        }
        return

    def prepare(self):
        """Prepare the operation.

        Includes:
        - Prepare ase_args for ASE and ase_run_file. Note: Must define `pdict.dft.calc_args.ase{}` for this function.
        - Prepare the task_list
        - Prepare forward & backward files
        - Prepare commandlist_list for multi-remote submission
        """
        work_dir = self.work_dir
        pdict = self.pdict

        # calc_args = self.calc_info["calc_args"]
        # optimize_args = self.calc_info["optimize_args"]

        ### Prepare ase_args
        ase_args = deepcopy(pdict.get("dft"))
        ase_args.pop("md", None)  # remove the MD key
        ase_args.setdefault("structure", {})["from_extxyz"] = f"{K.FILE_FRAME_UNLABEL}"
        # for p in dft_task_dirs:
        #     write_yaml(ase_args, f"{p}/{FILE_ARG_ASE}")

        ase_args = self._correct_ase_pyfile_path(ase_args)
        Config.validate(config_dict=ase_args, schema_file=K.SCHEMA_ASE_RUN)
        write_yaml(ase_args, f"{work_dir}/{K.FILE_ARG_ASE}")

        ### GPAW_runfile
        self.RUNFILE_ASE = "cli_ase_optimize.py"
        self._prepare_runfile_ase()
        return

    def _correct_ase_pyfile_path(self, ase_args) -> dict:
        """Fix calculator file path in ase_args."""
        pdict = deepcopy(self.pdict)
        ### Reassign calculator path (note: different key in cl and properties workflow)
        key = next((k for k in ["dft", "calculator"] if k in pdict), None)
        if key is not None:
            ### Extract and update the py_file
            py_file = pdict[key].get("calc_args", {}).get("ase", {}).get("py_file", "")
            self.CUSTOM_CALC_FILE = py_file
            ase_args["calc_args"]["ase"]["py_file"] = f"../{py_file}"

            ### Extract and update support_files if they exist
            support_files = pdict[key].get("calc_args", {}).get("ase", {}).get("support_files", [])
            self.SUPPORT_FILES = support_files
            if support_files:
                ase_args["calc_args"]["ase"]["support_files"] = [f"../{f}" for f in support_files]
        return ase_args

    def _prepare_runfile_ase(self):
        work_dir = self.work_dir

        ### GPAW_runfile
        RUNFILE_ASE = self.RUNFILE_ASE
        CUSTOM_CALC_FILE = self.CUSTOM_CALC_FILE
        _ = copy_file(
            f"{K.SCRIPT_ASE_PATH}/{RUNFILE_ASE}",
            f"{work_dir}/{RUNFILE_ASE}",
        )
        _ = copy_file(
            f"{CUSTOM_CALC_FILE}",
            f"{work_dir}/{CUSTOM_CALC_FILE}",
        )
        _ = [copy_file(f"{f}", f"{work_dir}/{f}") for f in self.SUPPORT_FILES]

        ### Prepare forward & backward files
        self.forward_common_files = [
            RUNFILE_ASE,
            K.FILE_ARG_ASE,
            CUSTOM_CALC_FILE,
            *self.SUPPORT_FILES,
        ]  # in work_dir
        self.forward_files = [K.FILE_FRAME_UNLABEL]  # files in task_path
        self.backward_files = [K.FILE_FRAME_LABEL, "calc*.txt", "run_out.log"]

        ### Prepare commandlist_list for multi-remote submission
        mdict_list = self.mdict_list
        commandlist_list = []
        for mdict in mdict_list:
            command_list = []
            dft_cmd = mdict.get("command", "gpaw python")
            dft_cmd = f"{dft_cmd} ../{RUNFILE_ASE} ../{K.FILE_ARG_ASE}"  # `../` to run file in common directory
            command_list.append(dft_cmd)
            commandlist_list.append(command_list)
        self.commandlist_list = commandlist_list
        return

    def postprocess(self):
        """This function does:
        - Remove unlabeled .extxyz files, just keep the labeled ones.
        """
        task_dirs = self.task_dirs
        ### Remove unlabeled extxyz files
        unlabel_paths = filter_dirs(task_dirs, has_files=[K.FILE_FRAME_UNLABEL, K.FILE_FRAME_LABEL])
        remove_files_in_paths(files=[K.FILE_FRAME_UNLABEL], paths=unlabel_paths)
        ### Remove unwanted keys in extxyz files
        extxyz_dirs = filter_dirs(task_dirs, has_files=[K.FILE_FRAME_LABEL])
        extxyz_files = [f"{d}/{K.FILE_FRAME_LABEL}" for d in extxyz_dirs]
        _ = [
            remove_key_in_extxyz(f, ["free_energy", "magmom", "magmoms", "dipole", "momenta"])
            for f in extxyz_files
        ]
        return


#####SECTION Classes for ASE Concurrent Learning
class OpClAseSinglepoint(OpGendataAseOptimize):
    def __init__(self, work_dir, pdict, multi_mdict, mdict_prefix="ase"):
        super().__init__(work_dir, pdict, multi_mdict, mdict_prefix)
        self.op_name = "ASE singlepoint"
        return

    def prepare(self):
        work_dir = self.work_dir
        pdict = self.pdict

        ### Prepare ase_args
        ase_args = deepcopy(pdict.get("dft"))
        ase_args.pop("md", None)  # remove the MD key
        ase_args.setdefault("structure", {})["from_extxyz"] = f"{K.FILE_FRAME_UNLABEL}"

        ase_args = self._correct_ase_pyfile_path(ase_args)
        write_yaml(ase_args, f"{work_dir}/{K.FILE_ARG_ASE}")
        Config.validate(config_dict=ase_args, schema_file=K.SCHEMA_ASE_RUN)

        ### GPAW_runfile
        self.RUNFILE_ASE = "cli_ase_singlepoint.py"
        self._prepare_runfile_ase()
        return

    def postprocess(self):
        """Do post DFT tasks."""
        ### Ref collect data in gendata
        # Nothing to do here
        return


###TODO: add ASE calculator for PES and Phonon compute
