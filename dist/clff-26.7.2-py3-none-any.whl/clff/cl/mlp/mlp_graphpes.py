"""Library for MLP training models [GraphPES](https://vldgroup.github.io/graph-pes/)."""
### https://github.com/vldgroup/graph-pes

import gc
import random
import shutil
import sys
from pathlib import Path

from natsort import natsorted

from asext.io.readwrite import read_extxyz
from clff.base import KEY as K
from clff.base import RemoteOperation, logger
from clff.cl.mlp.util_mlp import _free_cuda_memory, suggest_num_epochs
from clff.gdata.util_dataset import split_extxyz_dataset
from thkit.config import Config
from thkit.io import read_yaml, write_yaml
from thkit.log import silence_odd_loggers
from thkit.path import copy_file, list_paths, make_dir, move_file
from thkit.pkg import check_package


#####ANCHOR Active-learning
def pretrain_graphpes(work_dir, pdict, mdict):
    """Prepare arguments and data for GraphPES training.

    This mirrors `pretrain_sevenn` but uses `graph_pes` preprocessing and
    expects `graphpes_args` inside `pdict['train']`.

    Notes:
        - DIR_COLLECTDATA: is `tmp` directory containing collected extxyz data
        - DIR_FWDATA: directory containing `common_files` to forward to remote machines
    """
    # check_package("graph_pes", auto_install=False)

    pdict_train = pdict["train"]

    ### Split extxyz dataset
    logger.info("Split dataset")
    graphbuild_args = pdict_train.get("preprocess_data", {})
    train_ratio = graphbuild_args.get("trainset_ratio", 0.9)
    valid_ratio = graphbuild_args.get("validset_ratio", 0.1)
    split_extxyz_dataset(
        extxyz_files=[f"{work_dir}/{K.DIR_COLLECTDATA}/{K.FILE_COLLECT_DATA}"],
        train_ratio=train_ratio,
        valid_ratio=valid_ratio,
        outfile_prefix=f"{work_dir}/{K.DIR_COLLECTDATA}/data",  # will be: data_trainset.extxyz, data_validset.extxyz
    )

    ### Build graph_data
    logger.info("Prepare data (GraphPes)")
    if Path(f"{work_dir}/{K.DIR_FWDATA}/graphpes_data").exists():
        shutil.rmtree(f"{work_dir}/{K.DIR_FWDATA}/graphpes_data")

    move_file(
        f"{work_dir}/{K.DIR_COLLECTDATA}/data_trainset.extxyz",
        f"{work_dir}/{K.DIR_FWDATA}/graphpes_data/data_trainset.extxyz",
    )
    if valid_ratio > 0:
        move_file(
            f"{work_dir}/{K.DIR_COLLECTDATA}/data_validset.extxyz",
            f"{work_dir}/{K.DIR_FWDATA}/graphpes_data/data_validset.extxyz",
        )

    ### GraphPES args (user provides graphpes_args)
    logger.info("Prepare training args")
    graphpes_args = pdict_train["graphpes_args"]
    graphpes_args["wandb"] = None
    graphpes_args.setdefault("general", {}).update(
        {
            "progress": "logged",
            "root_dir": "graphpes_results",
            "run_id": "clff",
        }
    )

    graphpes_args.setdefault("data", {})
    graphpes_args["data"]["train"] = f"../{K.DIR_FWDATA}/graphpes_data/data_trainset.extxyz"
    if valid_ratio > 0:
        graphpes_args["data"]["valid"] = f"../{K.DIR_FWDATA}/graphpes_data/data_validset.extxyz"

    graphpes_args.setdefault("fitting", {}).setdefault("loader_kwargs", {})["batch_size"] = (
        pdict_train["batch_size"]
    )

    ### Guess num_epochs
    num_grad_updates = pdict_train.get("num_grad_updates", None)
    if num_grad_updates:
        list_atoms = read_extxyz(
            f"{work_dir}/{K.DIR_FWDATA}/graphpes_data/data_trainset.extxyz", index=":"
        )
        dataset_size = len(list_atoms)
        batch_size = pdict_train["batch_size"]
        num_epochs = suggest_num_epochs(dataset_size, batch_size, num_grad_updates)
        del list_atoms  # free memory
    else:
        num_epochs = pdict_train.get("num_epochs", 1000)

    graphpes_args["fitting"].setdefault("trainer_kwargs", {})["max_epochs"] = num_epochs
    if graphpes_args["fitting"].get("scheduler", None) == "linearlr":
        graphpes_args["fitting"]["scheduler"]["total_iters"] = num_epochs

    # graphpes_args["fitting"].setdefault("callbacks", [])
    # graphpes_args["fitting"]["callbacks"] += [
    #     {
    #         "+graph_pes.training.callbacks.DumpModel": {
    #             "every_n_val_checks": pdict_train["epoch_per_checkpoint"]
    #         }
    #     }
    # ]

    ### Copy init_checkpoints to DIR_FWDATA
    init_checkpoints = natsorted(pdict_train.get("init_checkpoints", []))
    if init_checkpoints:
        _ = [
            copy_file(fi, f"{work_dir}/{K.DIR_FWDATA}/init_checkpoint_{i}.pth")
            for i, fi in enumerate(init_checkpoints)
        ]

    ### Prepare train tasks (one folder for each training model)
    logger.info("Prepare train tasks")
    num_models = pdict_train.get("num_models", 1)
    task_dirs = [None] * num_models
    for i in range(num_models):
        model_path = Path(f"{work_dir}/model_{i:{K.FMT_MODEL}}")
        make_dir(model_path, backup=False)
        ### Set more args privately for each model
        graphpes_args["general"]["seed"] = random.randrange(2**16)
        if (
            init_checkpoints and Path(f"{work_dir}/{K.DIR_FWDATA}/init_checkpoint_{i}.pth").exists()
        ):  # continue training
            graphpes_args.pop("model", None)
            graphpes_args["model"] = {
                "+load_model": {
                    "path": f"../{K.DIR_FWDATA}/init_checkpoint_{i}.pth",
                }
            }

        schema_dict = read_yaml(K.SCHEMA_MLP_GRAPHPES)
        schema_dict.update(
            {"data": {"type": "dict"}, "wandb": {"type": "string", "nullable": True}}
        )
        Config.validate(config_dict=graphpes_args, schema_dict=schema_dict)
        write_yaml(graphpes_args, f"{model_path}/{K.FILE_ARG_TRAIN}")
        task_dirs[i] = model_path.as_posix()

    ### save task_dirs (relative to run_dir)
    write_yaml(task_dirs, f"{work_dir}/task_dirs.yml")
    gc.collect()
    return


class OpTrainGraphpes(RemoteOperation):
    def __init__(self, work_dir, pdict, multi_mdict, mdict_prefix="train"):
        super().__init__(work_dir, pdict, multi_mdict, mdict_prefix)
        self.op_name = "Training MLIP GraphPes"
        self.task_filter = {
            "has_files": [K.FILE_ARG_TRAIN],
            "no_files": ["**/model.pt"],
        }
        return

    # at here

    def prepare(self):
        pdict = self.pdict
        self.forward_common_files = [K.DIR_FWDATA]
        self.forward_files = [K.FILE_ARG_TRAIN]
        prefix = "graphpes_results/clff"
        self.backward_files = [
            f"{prefix}/rank-0.log",
            f"{prefix}/model.pt",
            f"{prefix}/lammps_model.pt",
            f"{prefix}/summary.yaml",
        ]

        mdict_list = self.mdict_list
        commandlist_list = []
        for mdict in mdict_list:
            command_list = []
            train_command = mdict.get("command", "graph-pes-train")
            train_command = f"{train_command} {K.FILE_ARG_TRAIN}"
            distributed_args = pdict["train"].get("distributed", None)
            if distributed_args:  ## run distributed training (MPI)
                cluster_type = distributed_args.get("cluster_type", "slurm")  # SLURM or SGE
                if cluster_type == "slurm":
                    gpu_per_node = mdict["resources"].get("gpu_per_node", 1)
                    train_command = (
                        f"srun {train_command} fitting/trainer_kwargs/devices={gpu_per_node}"
                    )
            command_list.append(train_command)
            commandlist_list.append(command_list)
        self.commandlist_list = commandlist_list
        return

    def postprocess(self):
        work_dir = self.work_dir
        task_dirs = self.task_dirs

        ### Collect the latest checkpoint file
        checkpoint_files: list = [None] * len(task_dirs)
        lammps_model_files: list = [None] * len(task_dirs)
        for i, task_dir in enumerate(task_dirs):
            seek_files = natsorted(list_paths(task_dir, patterns=["**/model.pt"]))
            if seek_files:
                checkpoint_files[i] = seek_files[-1]
            ### Lammps model
            seek_files = natsorted(list_paths(task_dir, patterns=["**/lammps_model.pt"]))
            if seek_files:
                lammps_model_files[i] = seek_files[-1]

        write_yaml(checkpoint_files, f"{work_dir}/{K.FILE_CHECKPOINTS}")
        write_yaml(lammps_model_files, f"{work_dir}/{K.FILE_LAMMPSMODELS}")
        return


#####ANCHOR Support functions
