"""---

<img src="./_assets/image/logo_clff.svg" style="float: left; margin-right: 20px" width="120"/>.

CLFF: Automated Framework for Concurrent Learning Force Fields and Material Properties Calculations.

Developed by [C.Thang Nguyen](https://thangckt.github.io/)

---
"""

from pathlib import Path

CLFF_ROOT = Path(__file__).parent

try:
    from ._version import version as __version__
except ImportError:
    __version__ = "0.1_fallback"

__author__ = "C.Thang Nguyen"
__contact__ = "http://thangckt.github.io/email/"


# warnings.filterwarnings(action="ignore", module=".*paramiko.*")
