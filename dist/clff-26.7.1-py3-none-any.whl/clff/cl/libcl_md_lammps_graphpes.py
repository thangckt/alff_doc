"""Library for LAMMPS MD with SevenNet model."""

import textwrap
from copy import deepcopy
from pathlib import Path

from clff import CLFF_ROOT
from clff.base import KEY as K
from clff.base import RemoteOperation
from clff.cl.libcl_md_lammps_sevenn import _sampling_report, temperature_press_mdarg_lammps
from clff.cl.utilcl import D3ParamMD, sort_task_dirs
from thkit.io import read_yaml, write_yaml
from thkit.path import collect_files, copy_file
from thkit.range import composite_index


#####ANCHOR pre MD Lammps
def premd_lammps_graphpes(work_dir, pdict, mdict):
    """Prepare MD args.

    Includes:
    - copy ML models to work_dir
    - collect initial configurations
    - prepare lammps args
    - generate task_dirs for ranges of temperature and press
    """
    ### note: work_dir = iter_dir/DIR_MD
    pdict_md = pdict["md"]

    ### copy ML_models to work_dir
    iter_dir = Path(work_dir).parent
    initial_checkpoints = read_yaml(f"{iter_dir}/{K.DIR_TRAIN}/{K.FILE_CHECKPOINTS}")
    checkpoints = [
        copy_file(p, p.replace(f"{K.DIR_TRAIN}", f"{K.DIR_MD}/{K.DIR_FWDATA}"))
        for p in initial_checkpoints
    ]
    write_yaml(checkpoints, f"{work_dir}/checkpoints.yml")

    initial_models = read_yaml(f"{iter_dir}/{K.DIR_TRAIN}/{K.FILE_LAMMPSMODELS}")
    models = [
        copy_file(p, p.replace(f"{K.DIR_TRAIN}", f"{K.DIR_MD}/{K.DIR_FWDATA}"))
        for p in initial_models
    ]
    write_yaml(models, f"{work_dir}/lammps_models.yml")

    ### collect initial configurations
    space_args: dict = read_yaml(f"{work_dir}/current_space.yml")
    init_struct_paths = pdict_md["init_struct_paths"]
    init_struct_idxs = list(set(composite_index(space_args.get("init_struct_idxs", []))))
    assert max(init_struct_idxs) < len(init_struct_paths), (
        "indices in 'init_struct_idxs' must be smaller than the number of 'init_struct_paths'"
    )

    structure_files = []
    struct_dict = {}  # save structures idx for information
    for idx in init_struct_idxs:
        files = sorted(collect_files(init_struct_paths[idx], patterns=["*.extxyz"]))
        copied_files = [
            copy_file(myfile, f"{work_dir}/idx{idx}_{i}/{K.FILE_FRAME_UNLABEL}")
            for i, myfile in enumerate(files)
        ]
        structure_files.extend(copied_files)
        struct_dict[f"init_struct_idx_{idx}"] = files  # relative to run_dir
    structure_dirs = [Path(fi).parent.as_posix() for fi in structure_files]
    write_yaml(structure_dirs, f"{work_dir}/structure_dirs.yml")
    write_yaml(struct_dict, f"{work_dir}/init_struct_paths.yml")

    ##### Prepare MD args
    temperature_list = space_args.get("temps", [])
    press_list = space_args.get("pressures", [])
    current_space_args = deepcopy(space_args)
    for key in ["init_struct_idxs", "temps", "pressures"]:
        current_space_args.pop(key, None)
    md_args = deepcopy(pdict_md.get("common_md_args", {}))
    md_args.update(current_space_args)

    ### Define LAMMPS args & checkpoint files (need convert checkpoint to lammps format)
    convert_args = pdict_md.get("checkpoint_conversion", {})
    # selected_chkp = checkpoints[convert_args.get("checkpoint_idx", 0)]
    # rel_deployed_chkp = Path(selected_chkp).relative_to(work_dir).as_posix()

    selected_model = models[convert_args.get("checkpoint_idx", 0)]
    rel_deployed_model = Path(selected_model).relative_to(work_dir).as_posix()

    lammps_args = {}
    lammps_args.setdefault("structure", {}).setdefault("extra_settings", [])
    extra_graphpes_kwargs = convert_args.get("extra_graphpes_kwargs", {})
    device = extra_graphpes_kwargs.get("device", "")  # error if set `gpu`
    ### D3 correction params
    ### There are combinations of (mlp_model, d3_package): mlp_model=["graphpes"], d3_package=["sevenn", "lammps"]
    dftd3_args = pdict_md.get("dftd3", None)
    if dftd3_args is not None:
        xc = dftd3_args.get("xc", "pbe")
        damping = dftd3_args.get("damping", "zero")
        twobody_cutoff = dftd3_args.get("twobody_cutoff", D3ParamMD().default_twobody_cutoff)
        cn_cutoff = dftd3_args.get("cn_cutoff", D3ParamMD().default_cn_cutoff)

        if dftd3_args.get("d3package", "sevenn") == "sevenn":
            ### use sevenn D3
            d3param = D3ParamMD("sevenn")
            damping = d3param.damping_map[damping]
            twobody_cutoff = d3param.angstrom2bohr2(twobody_cutoff)
            cn_cutoff = d3param.angstrom2bohr2(cn_cutoff)

            lammps_args["structure"].update(
                {
                    "pair_style": [
                        f"hybrid/overlay graph_pes {device} d3 {twobody_cutoff} {cn_cutoff} {damping} {xc}"
                    ],
                    "pair_coeff": [
                        f"* * graph_pes ../{rel_deployed_model} placeholder_for_atomnames",
                        "* * d3 placeholder_for_atomnames",
                    ],
                }
            )

        elif dftd3_args.get("d3package", "sevenn") == "lammps":
            ### use lammps' D3 in sevenn: https://github.com/MDIL-SNU/SevenNet/issues/246
            d3param = D3ParamMD("lammps")
            damping = d3param.damping_map[damping]

            lammps_args["structure"].update(
                {
                    "pair_style": [
                        f"hybrid/overlay graph_pes {device} dispersion/d3 {damping} {xc} {twobody_cutoff} {cn_cutoff}"
                    ],
                    "pair_coeff": [
                        f"* * graph_pes ../{rel_deployed_model} placeholder_for_atomnames",
                        "* * dispersion/d3 placeholder_for_atomnames",
                    ],
                }
            )
            lammps_args["structure"]["extra_settings"] += ["neigh_modify one 20000 page 1000000"]

    else:  # no D3 correction
        lammps_args["structure"].update(
            {
                "pair_style": [f"graph_pes {device}"],
                "pair_coeff": [f"* * ../{rel_deployed_model} placeholder_for_atomnames"],
            }
        )

    lammps_args["structure"]["extra_settings"] += ["newton off on"]

    lammps_args.update({"md": md_args})
    task_dirs = temperature_press_mdarg_lammps(
        structure_dirs, temperature_list, press_list, lammps_args
    )
    task_dirs = sort_task_dirs(task_dirs)
    write_yaml(task_dirs, f"{work_dir}/task_dirs.yml")

    ##### Write python script for compute committee_error and select candidates
    _ = copy_file(
        f"{CLFF_ROOT}/cl/utilcl_uncertainty.py",
        f"{work_dir}/{K.DIR_FWDATA}/utilcl_uncertainty.py",
    )
    committee_args = {  # default args
        "rel_force": None,
        "compute_stress": True,
        "rel_stress": None,
        "e_std_lo": 0.0,
        "e_std_hi": 0.15,
        "f_std_lo": 0.0,
        "f_std_hi": 0.15,
        "s_std_lo": 0.0,
        "s_std_hi": None,
    }
    committee_args.update(pdict_md.get("committee_std", {}))
    committee_str = ",\n        ".join([f"{k}={v}" for k, v in committee_args.items()])

    pyscript = textwrap.dedent(f"""
    import sys
    sys.path.append("../{K.DIR_FWDATA}")
    from utilcl_uncertainty import ModelCommittee, simple_lmpdump2extxyz
    from glob import glob

    lmpdump_file = "traj_md_label.lmpdump"
    extxyz_file = "{K.FILE_TRAJ_MD}"

    ### Covert lmpdump to extxyz
    simple_lmpdump2extxyz(lmpdump_file, extxyz_file)

    ### Select candidate configurations
    checkpoints = glob("../{K.DIR_FWDATA}/model*/**/model.pt")
    print(checkpoints)

    committee = ModelCommittee(
        mlp_model="graphpes",
        model_files=checkpoints,
        {committee_str},
    )
    committee.select_candidate(extxyz_file)
    """)
    with open(f"{work_dir}/{K.DIR_FWDATA}/cli_committee.py", "w") as f:
        f.write(pyscript)
    return


#####ANCHOR MD operation LammpsGraphpes
class OpClmdLammpsGraphpes(RemoteOperation):
    """This class runs LAMMPS md for a list of structures in `task_dirs`."""

    def __init__(self, work_dir, pdict, multi_mdict, mdict_prefix="md"):
        super().__init__(work_dir, pdict, multi_mdict, mdict_prefix)
        self.op_name = "LAMMPS MD with SevenNet"
        self.task_filter = {
            "has_files": ["conf.lmpdata"],
            "no_files": ["committee_error.txt"],
        }
        return

    def prepare(self):
        """Prepare MD tasks.

        Includes:
        - Prepare the task_list
        - Prepare forward & backward files
        - Prepare commandlist_list for multi-remote submission
        """
        ### Prepare forward & backward files
        self.forward_common_files = [K.DIR_FWDATA]  # in work_dir
        self.forward_files = ["conf.lmpdata", K.RUNFILE_LAMMPS]  # all files in task_dirs
        self.backward_files = [
            "*_stress_value.txt",
            "committee_*",
            "*.extxyz",
        ]  # FILE_TRAJ_MD, FILE_TRAJ_MD_CANDIDATE,

        ### Prepare commandlist_list for multi-remote submission
        mdict_list = self.mdict_list
        commandlist_list = []
        for mdict in mdict_list:
            command_list = []
            md_command = mdict.get("command", "lmp_mpi")
            md_command = f"{md_command} -in {K.RUNFILE_LAMMPS}"
            command_list.append(md_command)

            ### compute committee_error
            command = f"""(python ../{K.DIR_FWDATA}/cli_committee.py)"""
            command_list.append(command)
            commandlist_list.append(command_list)
        self.commandlist_list = commandlist_list
        return

    def postprocess(self):
        work_dir = self.work_dir
        task_dirs = self.task_dirs

        _sampling_report(work_dir, task_dirs)

        ### Clean up
        # md_traj_files = [f"{p}/{FILE_TRAJ_MD}" for p in task_dirs]
        # [Path(f).unlink() for f in md_traj_files if Path(f).exists()]
        return


#####ANCHOR Helper functions
