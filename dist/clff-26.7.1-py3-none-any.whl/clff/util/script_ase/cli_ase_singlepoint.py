"""Some notes
- Must set txt='calc.txt' in GPAW calculator for backward files.
- param_yaml must contain
    - a dict `calc_args.ase={}` define calculator.
"""

import argparse
from typing import cast

import yaml

from ase import Atoms
from ase.calculators.mixing import SumCalculator
from ase.io import read, write
from ase.parallel import parprint


#####ANCHOR Helper functions
def get_cli_args():
    """Get the arguments from the command line."""
    parser = argparse.ArgumentParser(description="The parser")
    parser.add_argument("param", type=str, help="The YAML file contains parameters")
    args = parser.parse_args()
    configfile = args.param
    with open(configfile) as f:
        pdict = yaml.safe_load(f)
    return pdict


pdict = get_cli_args()
calc_args = pdict.get("calc_args", {})

#####ANCHOR Define calculator
ase_calc_args = calc_args.get("ase", {})
if ase_calc_args.get("py_file", None):
    with open(ase_calc_args["py_file"]) as f:
        code_lines = f.read()
elif ase_calc_args.get("py_script", None):
    code_lines = "\n".join(ase_calc_args["py_script"])
else:
    raise ValueError("The calc_args.ase key must contain either py_file or py_script.")

### Dynamically execute custom lines
exec(code_lines)  # this will define `calc_ase` in the local scope

### DFTD3
dftd3_params = {
    "xc": "pbe",
    "damping": "zero",
    "abc": False,
    "cutoff": 50.2718,
    "cnthr": 21.1671,
}
dftd3_args = calc_args.get("dftd3", {})
if dftd3_args and not calc_args.get("exclude_result_dftd3", False):
    from ase.calculators.dftd3 import DFTD3

    parprint("INFO: Use DFTD3 for dispersion correction")
    dftd3_params.update(dftd3_args)
    calc_d3 = DFTD3(**dftd3_params)
    calc = SumCalculator([calc_ase, calc_d3])  # noqa: F821, # type: ignore

else:
    calc = calc_ase  # calc defined in the exec() above   # noqa: F821, # type: ignore

#####ANCHOR Define atoms
### atoms: read EXTXYZ file
struct_args = pdict["structure"]
extxyz_file = struct_args["from_extxyz"]
atoms = read(extxyz_file, format="extxyz", index="-1")
atoms = cast(Atoms, atoms)  # for type checker
input_pbc = struct_args.get("pbc", False)
if input_pbc:
    atoms.pbc = input_pbc

### set calculator
atoms.calc = calc

#####ANCHOR Calculation
### Note # `force_consistent=True` cause error if combine multi-calculators
pot_energy = atoms.get_potential_energy()
forces = atoms.get_forces()
try:  # compute stress when the calculator supports it
    stress = atoms.get_stress()
except Exception:
    stress = None
    pass

### Save results (only last frame)
atoms.info["pbc"] = atoms.get_pbc()

##### write output extxyz file (final frame)
output_file = extxyz_file.replace(".extxyz", "_label.extxyz")
write(output_file, atoms, format="extxyz")
