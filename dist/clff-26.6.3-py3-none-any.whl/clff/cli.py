"""Command line interfaces for CLFF workflows."""

import argparse


#####ANCHOR Processes
def clff_cl():
    """CLI for concurrent learning."""
    from clff.cl.concurrent_learning import WorkflowConcurrentLearning

    params_file, machines_file = get_cli_args()
    wf = WorkflowConcurrentLearning(params_file, machines_file)
    wf.run()
    return


def clff_finetune():
    """CLI for fine-tuning."""
    from clff.cl.finetune import WorkflowFinetune

    params_file, machines_file = get_cli_args()
    wf = WorkflowFinetune(params_file, machines_file)
    wf.run()
    return


def clff_gendata():
    """CLI for data generation."""
    from clff.gdata.gendata import WorkflowGendata

    params_file, machines_file = get_cli_args()
    wf = WorkflowGendata(params_file, machines_file)
    wf.run()
    return


def clff_phonon():
    """CLI for phonon calculation."""
    from clff.phonon.phonon import WorkflowPhonon

    params_file, machines_file = get_cli_args()
    wf = WorkflowPhonon(params_file, machines_file)
    wf.run()
    return


def clff_pes():
    """CLI for PES scanning calculation."""
    from clff.pes.pes_scan import WorkflowPes

    params_file, machines_file = get_cli_args()
    wf = WorkflowPes(params_file, machines_file)
    wf.run()
    return


def clff_elastic():
    """CLI for elastic constants calculation."""
    from clff.elastic.elastic import WorkflowElastic

    params_file, machines_file = get_cli_args()
    wf = WorkflowElastic(params_file, machines_file)
    wf.run()
    return


def convert_chgnet_to_xyz():
    """CLI for converting the MPCHGNet dataset to XYZ format."""
    from clff.gdata.convert_mpchgnet_to_xyz import run_convert

    run_convert()
    return


#####ANCHOR Helper functions
def get_cli_args() -> tuple[str, str]:
    """Get arguments from the command line."""
    parser = argparse.ArgumentParser()
    parser.add_argument(
        "params_file",
        type=str,
        help="The file contains setting parameters for the generator",
    )
    parser.add_argument(
        "machines_file",
        type=str,
        help="The file contains settings of the machine that running the generator",
    )
    args = parser.parse_args()
    params_file = args.params_file
    machines_file = args.machines_file
    return params_file, machines_file
