"""Elastic properties package."""
