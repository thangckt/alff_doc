"""Library for MLP training models [GraphPES](https://vldgroup.github.io/graph-pes/)."""
### https://github.com/vldgroup/graph-pes

from thkit.pkg import check_package

check_package("graph_pes", auto_install=False)

import gc
import shutil
import sys
from pathlib import Path

from natsort import natsorted

from asext.io.readwrite import read_extxyz
from clff.base import KEY as K
from clff.base import RemoteOperation, logger
from clff.cl.mlp.util_mlp import _free_cuda_memory, suggest_num_epochs
from clff.gdata.util_dataset import split_extxyz_dataset
from thkit.io import write_yaml
from thkit.log import silence_odd_loggers
from thkit.path import copy_file, list_paths, make_dir


def pretrain_graphpes(work_dir, pdict, mdict):
    """Prepare arguments and data for GraphPES training.

    This mirrors `pretrain_sevenn` but uses `graph_pes` preprocessing and
    expects `graphpes_args` inside `pdict['train']`.
    """
    pdict_train = pdict["train"]

    logger.info("Split dataset")
    ### Split extxyz dataset
    graphbuild_args = pdict_train.get("preprocess_data", {})
    train_ratio = graphbuild_args.get("trainset_ratio", 0.9)
    valid_ratio = graphbuild_args.get("validset_ratio", 0.1)
    split_extxyz_dataset(
        extxyz_files=[f"{work_dir}/{K.DIR_COLLECTDATA}/{K.FILE_COLLECT_DATA}"],
        train_ratio=train_ratio,
        valid_ratio=valid_ratio,
        outfile_prefix=f"{work_dir}/{K.DIR_COLLECTDATA}/data",
    )

    logger.info("Build graph data (GraphPES)")
    if Path(f"{work_dir}/{K.DIR_FWDATA}/graphpes_data").exists():
        shutil.rmtree(f"{work_dir}/{K.DIR_FWDATA}/graphpes_data")

    num_cores = graphbuild_args.get("num_cores", 1)
    ase_kwargs = graphbuild_args.get("ase_kwargs", {})

    graphpes_args = pdict_train.get("graphpes_args", {})
    cutoff = graphpes_args.get("model", {}).get("cutoff", None)

    build_graphdata_graphpes(
        files=[f"{work_dir}/{K.DIR_COLLECTDATA}/data_trainset.extxyz"],
        outdir=f"{work_dir}/{K.DIR_FWDATA}",
        outfile="graph_trainset.pt",
        num_cores=num_cores,
        cutoff=cutoff,
        **ase_kwargs,
    )
    gc.collect()

    if valid_ratio > 0:
        build_graphdata_graphpes(
            files=[f"{work_dir}/{K.DIR_COLLECTDATA}/data_validset.extxyz"],
            outdir=f"{work_dir}/{K.DIR_FWDATA}",
            outfile="graph_validset.pt",
            num_cores=num_cores,
            cutoff=cutoff,
            **ase_kwargs,
        )

    logger.info("Prepare training args")
    ### GraphPES args (user provides graphpes_args)
    if "graphpes_args" not in pdict_train:
        pdict_train["graphpes_args"] = {}
    graphpes_args = pdict_train["graphpes_args"]

    graphpes_args.setdefault("data", {})
    graphpes_args["data"]["load_trainset_path"] = [
        f"../{K.DIR_FWDATA}/graphpes_data/graph_trainset.pt"
    ]
    if valid_ratio > 0:
        graphpes_args["data"]["load_validset_path"] = [
            f"../{K.DIR_FWDATA}/graphpes_data/graph_validset.pt"
        ]

    ### Guess num_epochs
    num_grad_updates = pdict_train.get("num_grad_updates", None)
    if num_grad_updates:
        list_atoms = read_extxyz(f"{work_dir}/{K.DIR_COLLECTDATA}/data_trainset.extxyz", index=":")
        dataset_size = len(list_atoms)
        batch_size = graphpes_args.get("data", {}).get("batch_size", 1)
        num_epochs = suggest_num_epochs(dataset_size, batch_size, num_grad_updates)
        graphpes_args.setdefault("train", {})["epoch"] = num_epochs
        del list_atoms

    ### Copy init_checkpoints to DIR_FWDATA
    init_checkpoints = natsorted(pdict_train.get("init_checkpoints", []))
    if init_checkpoints:
        _ = [
            copy_file(fi, f"{work_dir}/{K.DIR_FWDATA}/init_checkpoint_{i}.pth")
            for i, fi in enumerate(init_checkpoints)
        ]

    logger.info("Prepare train tasks")
    num_models = pdict_train.get("num_models", 1)
    task_dirs = [None] * num_models
    for i in range(num_models):
        model_path = Path(f"{work_dir}/model_{i:{K.FMT_MODEL}}")
        make_dir(model_path, backup=False)
        graphpes_args.setdefault("train", {})["random_seed"] = None
        write_yaml(graphpes_args, f"{model_path}/{K.FILE_ARG_TRAIN}")
        task_dirs[i] = model_path.as_posix()

    write_yaml(task_dirs, f"{work_dir}/task_dirs.yml")
    gc.collect()
    return


class OperTrainGraphpes(RemoteOperation):
    def __init__(self, work_dir, pdict, multi_mdict, mdict_prefix="train"):
        super().__init__(work_dir, pdict, multi_mdict, mdict_prefix)
        self.op_name = "Training"
        self.task_filter = {"has_files": [K.FILE_ARG_TRAIN], "no_files": ["checkpoint_best.pth"]}
        return

    def prepare(self):
        pdict = self.pdict
        self.forward_common_files = [K.DIR_FWDATA]
        self.forward_files = [K.FILE_ARG_TRAIN]
        self.backward_files = ["checkpoint_*.pth", "log*.graphpes", "lc.csv"]

        mdict_list = self.mdict_list
        commandlist_list = []
        for mdict in mdict_list:
            command_list = []
            train_command = mdict.get("command", "graph_pes_train")
            command_list.append(train_command + f" {K.FILE_ARG_TRAIN}")
            commandlist_list.append(command_list)
        self.commandlist_list = commandlist_list
        return

    def postprocess(self):
        work_dir = self.work_dir
        task_dirs = self.task_dirs

        best_checkpoint_files: list = [None] * len(task_dirs)
        for i, task_dir in enumerate(task_dirs):
            checkpoint_files = list_paths(task_dir, patterns=["checkpoint_*.pth"])
            checkpoint_files = natsorted(checkpoint_files)
            if checkpoint_files:
                best_checkpoint_files[i] = checkpoint_files[-1]
                _ = [Path(f).unlink() for f in checkpoint_files[:-1]]

        write_yaml(best_checkpoint_files, f"{work_dir}/{K.FILE_CHECKPOINTS}")
        return


#####ANCHOR Support functions
def build_graphdata_graphpes(
    files: list[str],
    outfile: str = "graph_atoms.pt",
    outdir: str = ".",
    num_cores: int = 1,
    cutoff: float | None = None,
    **ase_kwargs,
):
    ### https://github.com/ACEsuit/mace/blob/main/mace/cli/preprocess_data.py
    """Build GraphPES graph dataset from source files.

    This function tries to detect a suitable API in the installed `graph_pes`
    package and invoke it. If the installed version is incompatible, an
    informative ImportError is raised.
    """
    try:
        from graph_pes.data.datasets import file_dataset
    except Exception as e:
        raise ImportError(f"graph_pes is not available: {e}")

    import torch

    silence_odd_loggers(ignore_list=["clff", "graph_pes"])

    outdir_path = Path(outdir) / "graphpes_data"
    outdir_path.mkdir(parents=True, exist_ok=True)
    target_path = outdir_path / outfile

    # graph-pes provides `file_dataset` to load ASE-readable files
    # Use pre_transform to cache neighbour lists, then materialize graphs
    path = Path(files[0])
    cutoff_val = cutoff if cutoff is not None else None

    ds = file_dataset(
        path,
        cutoff=cutoff_val,
        pre_transform=True,
        transform=None,
        **ase_kwargs,
    )

    # prepare_data() will cache on disk (rank-0). setup() materializes graphs
    try:
        ds.prepare_data()
    except Exception:
        # prepare_data may be a no-op depending on dataset
        pass
    try:
        ds.setup()
    except Exception:
        pass

    # `ds.graphs` may be a sequence; convert to list and save
    graphs = list(ds.graphs)
    torch.save(graphs, target_path)

    # cleanup
    del ds
    del graphs
    del gp
    _free_cuda_memory()
    gc.collect()
    return


def _free_memory_graphpes():
    """Free memory used by graph_pes and torch."""
    _free_cuda_memory()
    gc.collect()
    return
