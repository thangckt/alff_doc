"""Data generation package."""
